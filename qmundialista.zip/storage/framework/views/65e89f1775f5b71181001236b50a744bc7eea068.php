<div class="container-fluid">
        <?php echo $__env->make('common.crud_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('common.crud_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="d-flex flex-row align-items-start col-md-8 gap-2 mb-2">
            
            <?php if($allow_create): ?>
                <?php echo $__env->make('common.crud_create_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            
            <?php if(isset($view_search)): ?>
                <?php echo $__env->make($view_search, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>

        
        <?php if($confirm_delete): ?>
            <?php echo $__env->make('common.confirm_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        
        <?php if($view_table): ?>
            <div class="table-responsive bg-white">
                <?php echo $__env->make('common.crud_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>

        
        <?php if($isOpen && isset($view_form)): ?>
            <?php echo $__env->make('common.crud_modal_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/index.blade.php ENDPATH**/ ?>