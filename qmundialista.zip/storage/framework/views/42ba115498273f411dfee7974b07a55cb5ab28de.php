<div class="container">
    <div class="text-danger">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => []]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    <div class="row align-items-start">
        <div class="col-md-4 flex flex-col">
            <label class="input-group-text mb-2"><?php echo e(__("Company")); ?></label>
            <label class="input-group-text mb-2"><?php echo e(__("Total Codes")); ?></label>
            <label class="input-group-text mt-2"><?php echo e(__('Printed?')); ?></label>
        </div>

        <div class="col flex flex-col">

            <div class="flex-flex-column mb-2">

                

                <div class="flex-flex-column mb-2">

                    <select  wire:model="main_record.company_id"
                            class="form-select"
                            <?php if($main_record->codes->count()): ?> disabled <?php endif; ?>
                        >
                        <option value=""><?php echo e(__('Company')); ?></option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                class="block mt-0 text-sm leading-tight font-semibold text-gray-900 hover:underline"
                                value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                
                <div class="flex-flex-column mb-2">
                        <?php if($main_record->codes->count()): ?>
                            <label class="mb-2"><?php echo e($main_record->total_codes); ?></label>
                        <?php else: ?>
                            <input type="number"
                                    wire:model="main_record.total_codes"
                                    min="1"
                                    max="9999"
                                    required
                            >

                        <?php endif; ?>

                </div>

            

                <div class="flex-flex-column mt-2">
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" wire:model="printed" class="btn-check" name="type" id="printed" value="1" <?php if($main_record->printed): ?> disabled <?php endif; ?>>
                            <label class="btn btn-outline-danger" for="printed"><?php echo e(__('Yes')); ?></label>
                            <input type="radio" wire:model="printed" class="btn-check ml-4" name="type" id="no_printed" value="0" <?php if($main_record->printed): ?> disabled <?php endif; ?>>
                            <label class="btn btn-outline-success" for="no_printed"><?php echo e(__('No')); ?></label>
                        </div>
                </div>

            </div>

        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/companies/codes/form.blade.php ENDPATH**/ ?>