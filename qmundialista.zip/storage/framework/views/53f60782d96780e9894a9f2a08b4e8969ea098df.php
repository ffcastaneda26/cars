<!-- LOGO -->
<div class="navbar-brand-box text-center">
    <a href="<?php echo e(route('dashboard')); ?>" class="logo logo-light">
        
        <img class="rounded-circle avatar-xs" src="<?php echo e(asset('images/logo_qatar.jpg')); ?>">

    </a>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/logo.blade.php ENDPATH**/ ?>