
<div class="dropdown d-none d-lg-inline-block me-2">
    <?php if(App::isLocale('en')): ?>
        <button type="button" class="btn header-item noti-icon waves-effect" title="Cambiar a Español">
            <a href="/language/es" class="dropdown-item notify-item">
                <img src="<?php echo e(asset('images/mexico.png')); ?>" alt="user-image" height="25">
            </a>
        </button>
    <?php else: ?>
        <button type="button" class="btn header-item noti-icon waves-effect" title="Change to English">
            <a href="/language/en" class="dropdown-item notify-item">
                <img src="<?php echo e(asset('images/usa.png')); ?>" alt="user-image" height="25">
            </a>
        </button>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/change_language.blade.php ENDPATH**/ ?>