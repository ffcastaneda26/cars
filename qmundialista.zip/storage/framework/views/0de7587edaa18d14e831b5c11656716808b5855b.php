<div class="dropdown d-inline-block">
    <button type="button"
    class="btn header-item waves-effect"
    id="page-header-user-dropdown"
    data-bs-toggle="dropdown"
    aria-haspopup="true"
    aria-expanded="false">
        <?php if(Auth::user()->profile_photo_path): ?>
            <img width="32" height="32" class="rounded-circle object-cover" src="/storage/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
        <?php else: ?>
            <img width="32" height="32" class="rounded-circle object-cover" src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
        <?php endif; ?>
    </button>
    <div class="dropdown-menu dropdown-menu-end">
        <!-- item-->
        <?php if(!Auth::user()->update_account && !Auth::user()->change_password): ?>
            <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>"> <?php echo e(__('Profile')); ?></a>
        <?php endif; ?>

        <div class="dropdown-divider"></div>

        <!-- Authentication -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                            this.closest(\'form\').submit();']); ?>
                <?php echo e(__('Log Out')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/profile_logout.blade.php ENDPATH**/ ?>