<tr>
    <td>
        <label class="mx-auto text-2xl text-white text-bold  justify-center sm:mx-0 sm:h-10 sm:w-10">
            <?php echo e(__('No Records Found')); ?>

        </label>
    </td>
</tr>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/common/no_records_found.blade.php ENDPATH**/ ?>