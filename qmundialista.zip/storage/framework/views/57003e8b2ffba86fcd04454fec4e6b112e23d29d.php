<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('layouts.home.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .modal {
        background-color: rgba(0, 0, 0, 0.7);
    }

    body {
        font-family: 'Nunito', sans-serif;
        heigh:665px;
        background-color:#FFFFFF;
    }

    .equipo_ganador{
        background-color: green;
    }

    .equipo_perdedor{
        background-color: red;
    }
</style>
<body class="font-sans antialiased" data-sidebar="dark">
    <!-- Loader -->
    <?php echo $__env->make('layouts.home.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Wrapper -->
    <div id="layout-wrapper">
        <!-- Page Heading -->
        <?php if(isset($header)): ?>
            <header class="bg-white">
                <div class="d-flex">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- ===== Etiqueta header -->
        <?php echo $__env->make('layouts.home.header_div', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ========== Left Sidebar Start ========== -->
        <?php if(auth()->guard()->check()): ?>
        
            
                <?php echo $__env->make('layouts.home.left_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <?php endif; ?>

        <!-- Contenido Principal -->
        <?php echo $__env->make('layouts.home.main_content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--Pie de página -->
        <?php echo $__env->make('layouts.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo \Livewire\Livewire::scripts(); ?>

    
    <!-- JAVASCRIPT2 -->
    <?php echo $__env->make('layouts.home.javascript_files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top',
            showConfirmButton: false,
            showCloseButton: true,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        window.addEventListener('alert', ({
            detail: {
                type,
                message
            }
        }) => {
            Toast.fire({
                icon: type,
                title: message
            })
        })


        function confirm_modal(id) {
            var record = id;
            Swal.fire({
                title: "<?php echo e(__('Are you sure?')); ?>",
                text: "<?php echo e(__('You wo not be able to revert this!')); ?>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: "<?php echo e(__('Yes, delete it!')); ?>",
                cancelButtonText: "<?php echo e(__('Cancel')); ?>",
            }).then((result) => {
                if (result.isConfirmed) {
                    window.livewire.emit('destroy', record);
                    Swal.fire(
                        "<?php echo e(__('Deleted!')); ?>",
                        "<?php echo e(__('Your record has been deleted.')); ?>",
                        'success'
                    )
                }
            })
        }



    </script>
    <!-- add before </body> -->
    <script src="https://unpkg.com/filepond/dist/filepond.js"></script>
    
    <script src="https://cdn.ckeditor.com/ckeditor5/34.2.0/classic/ckeditor.js"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/app.blade.php ENDPATH**/ ?>