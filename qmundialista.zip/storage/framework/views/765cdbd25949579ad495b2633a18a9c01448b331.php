<td colspan="2" class="px-1 text-center">
    <button type="button"
        wire:click="edit(<?php echo e($record->id); ?>)"
        class="btn btn-success waves-effect"
        data-target="sample-modal"
        title="<?php echo e(__("Edit")); ?>">
        <i class="mdi mdi-eye-circle"></i>
    </button>

    <?php if($record->can_be_delete()): ?>
        <button  onclick="confirm_modal(<?php echo e($record->id); ?>)"
            class="btn btn-danger waves-effect waves-light"
            data-bs-toggle="modal"
            data-bs-target="#mySmallModalLabel"
            title="<?php echo e(__("Delete")); ?>">
            <i class="mdi mdi-delete"></i>
        </button>
    <?php else: ?>
        <button  type="button"
            class="btn btn-danger waves-effect waves-light"
            data-target="sample-modal"
            disabled
            title="<?php echo e(__("It ca not delete")); ?>">
            <i class="mdi mdi-delete"></i>
        </button>
    <?php endif; ?>
</td><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_actions.blade.php ENDPATH**/ ?>