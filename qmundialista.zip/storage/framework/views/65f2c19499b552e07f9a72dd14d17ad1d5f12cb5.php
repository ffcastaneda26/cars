<div class="modal-footer">
    <?php echo $__env->make('common.crud_save_cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_modal_footer.blade.php ENDPATH**/ ?>