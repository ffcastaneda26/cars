
<a href="javascript: void(0);" class="has-arrow waves-effect">
    <i class="mdi mdi-buffer"></i>
    <span> <?php echo e(__('Configuration')); ?></span>
</a>

<ul class="sub-menu" aria-expanded="false">
    <li>
        <a href="<?php echo e(route('users')); ?>" class="waves-effect">
            <i class="mdi mdi-account-box"></i>
            <span> <?php echo e(__('Users')); ?> </span>
            </a>
    </li>


    <li>
        <a href="<?php echo e(route('role')); ?>" class="waves-effect">
            <i class="mdi mdi-cube-outline"></i>
            <span> <?php echo e(__('Roles')); ?> </span>
        </a>
    </li>

    <li>
        <a href="<?php echo e(route('permission')); ?>" class="waves-effect">
            <i class="mdi mdi-calendar-check"></i>
            <span><?php echo e(__('Permissions')); ?></span>
        </a>
    </li>

    

    <li>
        <a href="<?php echo e(route('companies')); ?>" class="waves-effect">
            <i class="mdi-office-building-outline"></i>
            <span><?php echo e(__('Companies')); ?></span>
        </a>
    </li>


    

    <li>
        <a href="<?php echo e(route('codes-company')); ?>" class="waves-effect">
            <i class="mdi mdi-barcode"></i>
            <span><?php echo e(__('Codes Company')); ?></span>
        </a>
    </li>


    <li>
        <a href="<?php echo e(route('teams')); ?>" class="waves-effect">
            <i class="mdi mdi-microsoft-teams"></i>
            <span><?php echo e(__('Teams')); ?></span>
        </a>
    </li>


    <li>
        <a href="<?php echo e(route('rounds')); ?>" class="waves-effect">
            <i class="mdi mdi-calendar-month"></i>
            <span><?php echo e(__('Rounds')); ?></span>
        </a>
    </li>

    <li>
        <a href="<?php echo e(route('games')); ?>" class="waves-effect">
            <i class="mdi mdi-soccer-field"></i>
            <span><?php echo e(__('Games')); ?></span>
        </a>
    </li>

    <li>
        <a href="<?php echo e(route('competidors')); ?>" class="waves-effect">
            <i class="mdi mdi-account-group"></i>
            <span><?php echo e(__('Competidors')); ?></span>
        </a>
    </li>
</ul>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/menus/admin.blade.php ENDPATH**/ ?>