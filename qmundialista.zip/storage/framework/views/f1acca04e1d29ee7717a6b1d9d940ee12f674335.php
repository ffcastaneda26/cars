<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="d-flex justify-content-between">
                
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/footer.blade.php ENDPATH**/ ?>