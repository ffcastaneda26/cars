<?php if($records && $records->count()): ?>
    <div>
        <?php echo e($records->links()); ?>

    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_pagination.blade.php ENDPATH**/ ?>