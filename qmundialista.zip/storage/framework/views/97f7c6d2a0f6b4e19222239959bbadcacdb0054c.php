<tr>
    <td class="text-left"><?php echo e($record->company->name); ?></td>
    <td class="text-left"><?php echo e($record->user->name); ?></td>
    <td class="text-left"><?php echo e($record->total_codes); ?></td>
    <td class="text-center">
        <?php if($record->printed): ?>
            <label>  <?php echo e(__('Yes')); ?></label>
        <?php else: ?>
            <label class="text-danger"><?php echo e(__('No')); ?></label>
        <?php endif; ?>
    </td>
    <?php echo $__env->make('common.crud_actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</tr>

<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/code_process/list.blade.php ENDPATH**/ ?>