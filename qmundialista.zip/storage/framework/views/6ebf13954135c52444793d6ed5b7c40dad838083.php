<?php if($records->count()): ?>
    <table class="table table-hover mb-0">
        <?php if(isset($view_table)): ?>
            <?php echo $__env->make($view_table, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->make('livewire.each_record', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </table>
    <?php echo $__env->make('common.crud_pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('common.no_records_found', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_table.blade.php ENDPATH**/ ?>