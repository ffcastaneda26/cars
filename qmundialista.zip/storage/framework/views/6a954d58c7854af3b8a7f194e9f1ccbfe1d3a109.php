<tr>
    <td class="text-left"><?php echo e($record->company->name); ?></td>
    <td class="text-left"><?php echo e($record->user->name); ?></td>
    <td class="text-left"><?php echo e($record->total_codes); ?></td>
    <td class="text-center">
        <?php if($record->printed): ?>
            <label>  <?php echo e(__('Yes')); ?></label>
        <?php else: ?>
            <label class="text-danger"><?php echo e(__('No')); ?></label>
        <?php endif; ?>
    </td>
    <?php echo $__env->make('common.crud_actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <td>

            <button type="button"
                wire:click="export_codes(<?php echo e($record->id); ?>)"
                class="btn btn-info waves-effect waves-light"
                title="<?php echo e(__("Export")); ?>"
                <?php if(!$record->codes()->count()): ?> disbled <?php endif; ?>
                >
                <i class="mdi mdi-microsoft-excel"></i>
            </button>

    </td>
</tr>

<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/companies/codes/list.blade.php ENDPATH**/ ?>