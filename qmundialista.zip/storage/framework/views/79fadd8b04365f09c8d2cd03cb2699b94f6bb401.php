<thead>
    <tr class="bg-dark text-white text-center">
        <th><?php echo app('translator')->get("Company"); ?></th>
        <th><?php echo app('translator')->get("Creted By"); ?></th>
        <th class="text-left"><?php echo app('translator')->get("Total Codes"); ?></th>
        <th class="text-left"><?php echo app('translator')->get("Printed"); ?></th>
        <th class="text-center"><?php echo e(__("Actions")); ?></th>
    </tr>
</thead>

<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/code_process/table.blade.php ENDPATH**/ ?>