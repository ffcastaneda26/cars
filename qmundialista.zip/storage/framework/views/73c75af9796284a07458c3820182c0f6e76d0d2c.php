<thead>
    <tr class="bg-dark text-white text-center">
        <th><?php echo app('translator')->get("Name"); ?></th>
        <th><?php echo app('translator')->get("Email"); ?></th>
        <th><?php echo app('translator')->get("Address"); ?></th>
        <th><?php echo app('translator')->get("Phone"); ?></th>
        <th><?php echo app('translator')->get("Code"); ?></th>
        <th><?php echo app('translator')->get("Active"); ?></th>
        <th><?php echo app('translator')->get("Logo"); ?></th>

        <th colspan="2" class="text-center"><?php echo e(__("Actions")); ?></th>
    </tr>
</thead>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/companies/table.blade.php ENDPATH**/ ?>