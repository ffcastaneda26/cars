<div id="preloader">
    <div id="status">
        <div class="spinner"></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/loader.blade.php ENDPATH**/ ?>