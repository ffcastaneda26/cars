<?php if($allow_create): ?>
    <button wire:click="create()" class="btn btn-info">
        <?php echo e(__($create_button_label)); ?>

    </button>
<?php endif; ?><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_create_button.blade.php ENDPATH**/ ?>