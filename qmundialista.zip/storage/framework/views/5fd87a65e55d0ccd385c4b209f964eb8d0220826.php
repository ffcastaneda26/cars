
<div class="d-flex justify-content-end">
    
        <span class="mx-2">
            <button wire:click="closeModal()" type="button"
                class="btn btn-danger">
                <?php echo e(__("Cancel")); ?>

            </button>
        </span>

        <span class="mx-2">
            <button type="button"
                    wire:click.prevent="store()" 
                    <?php if(!$allow_save): ?> disabled <?php endif; ?>
                    class="btn btn-success">
                <?php echo e(__("Save")); ?>

               
            </button>
        </span>
  
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_save_cancel.blade.php ENDPATH**/ ?>