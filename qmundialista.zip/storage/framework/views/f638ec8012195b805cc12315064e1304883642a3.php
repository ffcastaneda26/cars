<tr>
    <td><?php echo e($record->name); ?></td>
    <td><?php echo e($record->email); ?></td>
    <td><?php echo e($record->address); ?></td>
    <td><?php echo e($record->phone); ?></td>
    <td><?php echo e($record->code); ?></td>
    <td class="text-center">

        <?php if($record->active): ?>
            <label>  <?php echo e(__('Yes')); ?></label>
        <?php else: ?>
            <label class="text-danger"><?php echo e(__('No')); ?></label>

        <?php endif; ?>

    </td>
    <td class="text-center">
        <?php if($record->logotipo): ?>
            <img class="avatar-md" src="<?php echo e(url('storage/'.$record->logotipo)); ?>" alt="<?php echo e(__('Image')); ?>">
        <?php endif; ?>
    </td>
    <?php echo $__env->make('common.crud_actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</tr>

<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/companies/list.blade.php ENDPATH**/ ?>