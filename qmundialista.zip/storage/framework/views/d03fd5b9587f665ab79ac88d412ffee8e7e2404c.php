<tbody>
    <?php echo $__env->renderEach($view_list,$records,'record','common.no_records_found'); ?>
</tbody>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/livewire/each_record.blade.php ENDPATH**/ ?>