<div class="main-content" id="result">
    <div class="page-content">
        <?php echo e($slot); ?>


        <?php echo $__env->yieldPushContent('modals'); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/main_content.blade.php ENDPATH**/ ?>