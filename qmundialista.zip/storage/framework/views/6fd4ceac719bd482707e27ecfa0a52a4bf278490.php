<!-- Search input -->
<div class="search-bar">
    <input class="search-input form-control"
            wire:model="search"
            placeholder="<?php echo e(__($search_label)); ?>"
    >
</div><?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_search.blade.php ENDPATH**/ ?>