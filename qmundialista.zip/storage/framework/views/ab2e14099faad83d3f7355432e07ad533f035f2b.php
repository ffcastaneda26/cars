<?php if(session()->has('message')): ?>
    <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
    <div class="flex">
        <div>

            <?php if($member_expired): ?>
                <p class="text-danger text-2xl font-bold"><?php echo e(session('message')); ?></p>
            <?php else: ?>
                <p class="text-sm"><?php echo e(session('message')); ?></p>
            <?php endif; ?>

        </div>
    </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/common/crud_message.blade.php ENDPATH**/ ?>