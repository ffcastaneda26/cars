<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <?php echo $__env->make('layouts.home.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Botón contraer barra lateral -->
            <?php echo $__env->make('layouts.home.button_show_hide_lateral_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <div class="d-flex">
            <?php echo $__env->yieldContent('main_title'); ?>

        </div>
        <div class="d-flex">
            <!-- Cambio de idioma -->
            <?php echo $__env->make('layouts.home.change_language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php echo $__env->make('layouts.home.profile_logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>
</header>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/layouts/home/header_div.blade.php ENDPATH**/ ?>