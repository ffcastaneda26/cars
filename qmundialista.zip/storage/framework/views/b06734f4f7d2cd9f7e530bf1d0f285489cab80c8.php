<a href="/">
    

    <img class="rounded-xs mx-auto" src="<?php echo e(asset('images/logo_qatar.jpg')); ?>" width="30%" alt="Qatar 2022">

</a>
<?php /**PATH C:\laragon\www\qmundialista\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>