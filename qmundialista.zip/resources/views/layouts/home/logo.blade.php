<!-- LOGO -->
<div class="navbar-brand-box text-center">
    <a href="{{route('dashboard')}}" class="logo logo-light">
        {{-- Clase: avatar-xx md=mediano sm=pequeño  xs=Extra pequeño lg=Largo xl=Extra largo --}}
        <img class="rounded-circle avatar-xs" src="{{asset('images/logo_qatar.jpg')}}">

    </a>
</div>
