<div id="preloader">
    <div id="status">
        <div class="spinner"></div>
    </div>
</div>
