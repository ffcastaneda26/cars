<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
<script src="/admiria/assets/libs/jquery/jquery.min.js"></script>
<script src="/admiria/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/admiria/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="/admiria/assets/libs/simplebar/simplebar.min.js"></script>
<script src="/admiria/assets/libs/node-waves/waves.min.js"></script>
<script src="/admiria/assets/js/app.js"></script>
<script src="/admiria/assets/js/my_functions.js"></script>
