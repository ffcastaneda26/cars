<div class="modal-header">
    <h5 class="modal-title mt-0" id="myModal"> {{$create_button_label}}</h5>
    <button type="button" class="btn-close" wire:click.prevent="closeModal()"
    data-bs-dismiss="modal" aria-label="Close"></button>
</div>