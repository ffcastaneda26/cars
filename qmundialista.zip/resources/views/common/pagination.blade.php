@if(isset($records) && $records)
    {{ $records->links() }}
@endif
