<tr>
    <td>
        <label class="mx-auto text-2xl text-white text-bold  justify-center sm:mx-0 sm:h-10 sm:w-10">
            {{ __('No Records Found')}}
        </label>
    </td>
</tr>
