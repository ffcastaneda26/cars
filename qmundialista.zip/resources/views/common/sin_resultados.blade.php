<tr>
    <td>
        <label class="mx-auto text-2xl text-white text-bold  justify-center h-50  w-50  rounded-full bg-red-600 sm:mx-0 sm:h-10 sm:w-10">
           Sin Resultados
        </label>
    </td>
</tr>
