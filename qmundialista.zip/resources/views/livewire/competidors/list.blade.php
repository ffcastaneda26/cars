<tr>
    <td>{{$record->fullName}}</td>
    <td>{{$record->phone}}</td>
    <td>{{$record->email}}</td>
    @include('common.crud_actions')
</tr>

