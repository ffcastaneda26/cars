<thead>
    <tr class="bg-dark text-white text-center">
        <th>{{__("Name")}}</th>
        <th>{{__("Phone")}}</th>
        <th>{{__("Email")}}</th>

        <th class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>