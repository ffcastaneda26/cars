<thead>
    <tr class="bg-dark text-white text-center">
        <th>@lang("Company")</th>
        <th>@lang("Creted By")</th>
        <th class="text-left">@lang("Total Codes")</th>
        <th class="text-left">@lang("Printed")</th>
        <th colspan="3" class="text-center">{{__("Actions")}}</th>

    </tr>
</thead>

