<thead>
    <tr class="bg-dark text-white">
        <th>{{__("Name")}}</th>
        <th>{{__("Email")}}</th>
        <th>{{__("Rol")}}</th>
        <th class="text-center">{{__("Active?")}}</th>
        <th class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>
