<tr>
    <td>{{ $record->spanish }}</td>
    <td>{{ $record->short_spanish }}</td>
    <td>{{ $record->english }}</td>
    <td>{{ $record->short_english }}</td>

    @include('common.crud_actions')
</tr>

