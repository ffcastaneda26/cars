<thead>
    <tr class="bg-dark text-white text-center">
        <th>@lang("Spanish")</th>
        <th>@lang("Short")</th>
        <th>@lang("English")</th>
        <th>@lang("Short")</th>

        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>
