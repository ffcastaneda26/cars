<thead>
    <tr class="bg-dark text-white text-center">
        <th>@lang("Id")</th>
        <th>@lang("From")</th>
        <th>@lang("To")</th>
        <th>@lang("Active")</th>

        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>

