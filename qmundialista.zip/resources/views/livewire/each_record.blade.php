<tbody>
    @each($view_list,$records,'record','common.no_records_found')
</tbody>
