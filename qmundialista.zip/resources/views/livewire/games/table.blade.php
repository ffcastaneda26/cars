<thead>
    <tr class="bg-dark text-white text-center">
        <th>@lang("Date")</th>
        <th colspan="2" class="text-left">@lang("Local")</th>
        <th colspan="2" class="text-left">@lang("Visit")</th>
        <th>@lang("Request Score")</th>
        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>

