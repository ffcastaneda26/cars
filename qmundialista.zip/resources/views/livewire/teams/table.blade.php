<thead>
    <tr class="bg-dark text-white text-center">
        <th>@lang("Name")</th>
        <th>@lang("Alias")</th>
        <th>@lang("Short")</th>
        <th>@lang("Logotipo")</th>
        <th>@lang("Request Score")</th>
        <th>@lang("Active")</th>

        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>

