<div>
    @section('main_title')
        <h2>{{$competidor->full_name}}</h2>
    @endsection
    @include($view_show)

</div>
