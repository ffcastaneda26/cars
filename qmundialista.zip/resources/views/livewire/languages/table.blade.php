<thead>
    <tr class="h5 bg-dark text-white">
        <th>{{__("Spanish")}}</th>
        <th>{{__("English")}}</th>
        <th>{{__("Image")}}</th>
        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>
