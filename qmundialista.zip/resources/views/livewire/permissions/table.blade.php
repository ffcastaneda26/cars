<thead>
    <tr class="bg-dark text-white text-center">
        <th>{{__("Permission")}}</th>
        <th>{{__("Description")}}</th>
        <th>{{__("Slug")}}</th>
        <th colspan="2" class="text-center">{{__("Actions")}}</th>
    </tr>
</thead>
