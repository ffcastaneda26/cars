<?php return array (
  'codes-company' => 'App\\Http\\Livewire\\CodesCompany',
  'companies' => 'App\\Http\\Livewire\\Companies',
  'competidors' => 'App\\Http\\Livewire\\Competidors',
  'games' => 'App\\Http\\Livewire\\Games',
  'languages' => 'App\\Http\\Livewire\\Languages',
  'permissions' => 'App\\Http\\Livewire\\Permissions',
  'picks' => 'App\\Http\\Livewire\\Picks',
  'roles' => 'App\\Http\\Livewire\\Roles',
  'rounds' => 'App\\Http\\Livewire\\Rounds',
  'statuses' => 'App\\Http\\Livewire\\Statuses',
  'teams' => 'App\\Http\\Livewire\\Teams',
  'users' => 'App\\Http\\Livewire\\Users',
);